WebGL build of SharpEngine Demo

Open index.html in a browser (Chrome, Edge, Firefox, Safari), or upload this whole folder to any web host.
Controls: hold the right mouse button and use W/A/S/D/Q/E to fly, Tab / Shift+Tab or 1-9 to change scene.
